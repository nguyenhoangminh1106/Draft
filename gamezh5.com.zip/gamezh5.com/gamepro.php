<?php
include './db.php';
include './header.php';
include './menu.php';
include './slide.php';
?>

<?php
$msisdn = "";
if(isset($_COOKIE['msisdn'])){

    $msisdn = $_COOKIE['msisdn'];
    if($msisdn != '855null'){    
    
    $regs_active = get_active($msisdn);
    
    $regs = array();
    if ($regs_active != null) {
        foreach ($regs_active as $i => $dk) {
            array_push($regs, $dk['pkg_code']);
            }
        }
    }

}
?>

<?php
$games = getListGameHomeHtml5();
?>

<section style="background-color: rgba(204,204,204, 0.2);">
    <div>
        <div class="tieude">
            <div class="tieude-ds game-title">
                <a href="<?php echo $context_path ?>/gogame">
                    <p style="color: #414141;">GoGame</p>
                </a>
                <hr class="game_line" width="150px;" align="center" color="#54B243"/>
            </div>
            <div class="tieude-ds game-title">
                <a href="<?php echo $context_path ?>/gamepro">
                    <p style="color: red;">GamePro</p>
                </a>
                <hr class="game_line" width="150px;" align="center" color="#54B243"/>
            </div>

            
            
        </div>

        <div class="game" style="padding-bottom:15px;">
            <div class="container resetp_ipad padding: 0">
                <div class="row list_game f-top-icon" style="padding-bottom:0px;">

                    <!-- <a class = "register-account primary lel1" data-toggle = "modal" href = "#reg-modal">Đăng ký</a> -->

                    <?php foreach ($games as $i => $game) { ?>
                        <div class="col-xl-4 col-md-6 col-lg-4 col-12">
                            <div class="row t_bdrus game-item-left" style="padding:10px;">
                                <div class="col-sm-4 col-4 col-lg-4 col-xl-4" style="padding:0px">
                                    <?php if(in_array('GHD_GameH5_GamePro_Daily', $regs, true)){ ?>
                                        <a href='<?php echo $context_path ?>/detail?id=<?php echo $game['id'] ?>'>
                                            <img class="" src="<?php echo $context_path ?>/images/game/<?php echo $game['image'] ?>" width="90%"/>
                                        </a> 
                                    <?php } else { ?>
                                        <a data-toggle = "modal" href = "#reg-modal">
                                            <img class="" src="<?php echo $context_path ?>/images/game/<?php echo $game['image'] ?>" width="90%"/>
                                        </a>
                                    <?php } ?>
                                                                                              
                                </div>

                                <div class="col-sm-8 col-md-8 col-8" style="padding:0 15px 0 15px">
                                    <div class="row titlle_game">
                                        <?php if(in_array('GHD_GameH5_GamePro_Daily', $regs, true)){ ?>
                                            <a class="all-game-name" href='<?php echo $context_path ?>/detail?id=<?php echo $game['id'] ?>'>
                                                <h5 class="t-tebgame" style="font-size:100%;margin-bottom:0">
                                                    <?php echo $game['name_eng'] ?>
                                                </h5>
                                            </a>
                                        <?php } else { ?>
                                            <a class="all-game-name" data-toggle = "modal" href = "#reg-modal">
                                                <h5 class="t-tebgame" style="font-size:100%;margin-bottom:0">
                                                    <?php echo $game['name_eng'] ?>
                                                </h5>
                                            </a>
                                        <?php } ?>                                        
                                    </div>

                                    <div class="row social-theloai-nguoichoi" style="padding-bottom: 10px;justify-content: left; line-height: 1">
                                        <ul class="list-icon" width="100%" height="25px" style="margin-bottom:0px;">
                                            <li class="ico-theloai">
                                                <a href="" data-lity>
                                                    <img width="100%" src="<?php echo $context_path ?>/img/new/ico_theloai.png"/>
                                                </a>
                                                <span class="fz_ip" style="font-size:70%;padding-left: 5px;padding-right: 5px;color: #888;"><?php echo $game['category_eng'] ?> |</span>                                                                        
                                            </li>
                                            <li class="ico-nguoichoi">
                                                <a>
                                                    <img style="" width="100%" src="<?php echo $context_path ?>/img/detail_game/intro/ico_user.png" />
                                                </a>
                                                <span class="fz_ip" style="font-size:70%;color: #888;"><?php echo $game['viewed'] ?> player |</span>
                                            </li>
                                            <li class="ico-nguoichoi">                                                
                                                <p class="fz_ip" style="font-size:70%;color: #888; padding-top: 5px;"><?php echo $game['intro'] ?></p>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="row social-theloai-nguoichoi" style="justify-content: left;position:absolute;bottom:0">
                                        <div class="mid2 pd_mb">
                                            <div class="text-left pc-view">
                                                <?php if(in_array('GHD_GameH5_GamePro_Daily', $regs, true)){ ?>
                                                    <a href='<?php echo $context_path ?>/play?id=<?php echo $game['id'] ?>'>
                                                        <img onmouseover="this.src = '<?php echo $context_path ?>/img/btn_play_hov.png'" onmouseout="this.src = '<?php echo $context_path ?>/img/btn_play_nor.png'"  src="<?php echo $context_path ?>/img/btn_play_nor.png" class="t_hinh2 t_hinh22" >
                                                    </a>
                                                <?php } else { ?>
                                                    <a data-toggle = "modal" href = "#reg-modal">
                                                        <img onmouseover="this.src = '<?php echo $context_path ?>/img/btn_play_hov.png'" onmouseout="this.src = '<?php echo $context_path ?>/img/btn_play_nor.png'"  src="<?php echo $context_path ?>/img/btn_play_nor.png" class="t_hinh2 t_hinh22" >
                                                    </a>
                                                <?php } ?>    
                                                
                                            </div>
                                            <div class="text-left mb-view">
                                                <?php if(in_array('GHD_GameH5_GamePro_Daily', $regs, true)){ ?>
                                                    <a id="btn_play_9" style="text-decoration: none;" href="<?php echo $context_path ?>/detail?id=<?php echo $game['id'] ?>">
                                                    <img src="<?php echo $context_path ?>/img/btn_play_hov.png" class="t_hinh2" >
                                                </a>
                                                <?php } else { ?>
                                                    <a id="btn_play_9" style="text-decoration: none;" data-toggle = "modal" href = "#reg-modal">
                                                        <img src="<?php echo $context_path ?>/img/btn_play_hov.png" class="t_hinh2" >
                                                    </a>
                                                <?php } ?>
                                                
                                            </div>  
                                        </div>
                                    </div>       
                                </div>
                            </div>                                                    
                        </div>
                    <?php } ?>                    

                </div>	
            </div>

        </div>
    </section>

<!--modal register-->
<div class="modal fade" id="reg-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="text-align: center">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">You have not subscribed to the GamePro package of the Game H5 service. Click register to play the game</h4>
            </div>
            <div class="modal-body">
               <a href="/register.php?pkg=GHD_GameH5_GamePro_Daily" class="register-button">SUBSCRIBE PRO</a>                            
            </div>
            <div class="modal-footer" style="text-align: center; margin: 0 auto;">
                <center><a style="color:white; background-color: darkred;" type="button" class="register-button" data-dismiss="modal">Exit</a></center>
            </div>
        </div>
    </div>
</div>

<?php include './footer.php'; ?>
