<?php

header('Location: /');
exit();

?>