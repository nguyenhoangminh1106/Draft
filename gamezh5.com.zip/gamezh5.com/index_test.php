<?php
include_once ('./config.php');
include_once ('./db.php');
include_once ('./function.php');

?>

<?php

$msisdn = null;
$is_detect = false;
$is_reg = false;

if (isset($_COOKIE["msisdn"])) {
    $msisdn = $_COOKIE["msisdn"];
    $is_detect = true;
} else {
    //$ip = get_client_ip();
    //$ip_2 = explode('.', $ip)[0] . '.' . explode('.', $ip)[1];
    //if (in_array($ip_2, explode(',', $ip_pool), true)) {
        //$req_id = 'GHD_GameH5_GoGame_Daily.'.round(microtime(true));
        //$input = "SUB=GHD_GameH5_GoGame_Daily&REQ=" . $req_id . "&SOURCE=WAP&SESS=" . $req_id;
        //$aes_key = bin2hex(openssl_random_pseudo_bytes(16));        
        //$value_encrypt_aes = encrypt_aes($input, $aes_key);
        //$value_with_key = 'value=' . $value_encrypt_aes . '&key=' . $aes_key;
        //$encode = encrypt_rsa($value_with_key);
        //$sign = sign_data($encode, $pri_cp_path);
        //$link = $mps_url . 'mobile.html?PRO=GHD&SER=GHD_GameH5&SUB=GHD_GameH5_GoGame_Daily&DATA=' . urlencode($encode) . '&SIG=' . $sign;
        //header("Location: " .$link);
        //die();
    //}
}

?>

<?php

$regs = array();
if($msisdn != '855null'){
    $data = check_register($msisdn);
    $regs_active = get_active($msisdn);
    if (isset($data['pkg_code'])) {
        $is_reg = true;        
    }

    if ($regs_active != null) {
        foreach ($regs_active as $i => $dk) {
            array_push($regs, $dk['pkg_code']);
        }
    }
}

setcookie("is_reg", $is_reg , time() + 86400, "/");

?>

<?php
    $games = getTopGameHtml5();
    $gameSlides = getSlideGameHtml5();
    $goGames = getGoGameHtml5();
    $pageGamePro = ceil(sizeof($gameSlides)/6);
    $pageGoGame= ceil(sizeof($goGames)/6);
?>

<?php 
include_once ('./header.php');
include_once ('./menu.php');
include_once ('./slide.php');
?>
<div class="vas-info">
    <center>
        <h3 style="font-size: 16px; padding: 10px;">            
            <?php if($is_detect && $msisdn != '855null' && !$is_reg){ ?>
                <span>Wellcome to <?php echo $msisdn ?>. You have not subscribed for Game H5 service. To subscribe, send GO to 1541 (GoGame Package, Fee: 10c/day); send PRO to 1541 (GamePro package, Fee: 15c/day)</span>
            <?php }else if($is_detect && $msisdn != '855null' && $is_reg){

                if (in_array('GHD_GameH5_GoGame_Daily', $regs, true) && !in_array('GHD_GameH5_GamePro_Daily', $regs, true)) { ?>

                    <span>Wellcome to <?php echo $msisdn ?>, you are using GoGame package of Game H5 sevice. To cancel, send OFF GO to 1541 or click [<a href="/cancel.php?pkg=GHD_GameH5_GoGame_Daily">OFF</a>]</span>

                <?php }else if(!in_array('GHD_GameH5_GoGame_Daily', $regs, true) && in_array('GHD_GameH5_GamePro_Daily', $regs, true)){ ?>

                    <span>Wellcome to <?php echo $msisdn ?>, you are using GamePro package of Game H5 sevice. To cancel, send OFF PRO to 1541 or click [<a href="/cancel.php?pkg=GHD_GameH5_GamePro_Daily">OFF</a>]</span>

                <?php } else if(in_array('GHD_GameH5_GoGame_Daily', $regs, true) && in_array('GHD_GameH5_GamePro_Daily', $regs, true)) { ?>

                    <span>Welcome <?php echo $msisdn ?>, you are using GamePro package and GoGame package of Game H5 sevice. To cancel, send OFF PRO to 1541 and OFF GO to 1541<br/>
                    [<a href="/cancel.php?pkg=GHD_GameH5_GoGame_Daily">OFF GOGAME</a>] [<a href="cancel.php?pkg=GHD_GameH5_GamePro_Daily">OFF GAMEPRO</a>]
                    </span>

            <?php }
            }else{ ?>
                <span>Welcome to Game H5. You have not subscribed for Game H5 service. To subscribe, send GO to 1541 (GoGame Package, Fee: 10c/day); send PRO to 1541 (GamePro package, Fee: 15c/day)</span>
            <?php } ?>

            <br/>
            <?php if (!in_array('GHD_GameH5_GoGame_Daily', $regs, true)) { ?>
                <a href="/register.php?pkg=GHD_GameH5_GoGame_Daily" class="register-button">SUBSCRIBE GO</a> 
            <?php } ?>

            <?php if (!in_array('GHD_GameH5_GamePro_Daily', $regs, true)) { ?>
                <a href="/register.php?pkg=GHD_GameH5_GamePro_Daily" class="register-button">SUBSCRIBE PRO</a>
            <?php } ?>
        </h3>
    </center>
</div>
<section id="f-game-thumnail">
    <div class="container">
        <div class="row">
            <div class="col-sm-8 padding-reset-left-right row-eq-height" id="f-game-select" style="padding-bottom: 10px">
                
                <!-- <div class="container">
                <h3 class="entry-heading" style="display: flex;">
                    <span style="font-weight: bold;">GAMEPRO</span>
                    <a style="font-style: italic; margin-left: auto; color: rgb(11, 162, 75);" href="<?php echo $context_path ?>/gamepro">
                        <span style="font-size: 20px">MORE>></span>
                    </a>
                </h3>
                    <div id="gamepro">
                        <?php for ($k=0; $k<$pageGamePro; $k++) {?>
                            <div id="item">
                                <div class="row">
                                    <?php for ($i=0; $i<6; $i++) { $p=($k*6)+$i?>  
                                        <div class="col-sm-4 pdr_ip5 reset-padding-left col-6">
                                            <div class="container">
                                                <div class="card f-card-game t_bdrus" style="margin-top: 15px;">
                                                    <?php if(1==1){ ?>
                                                        <a class="f-game-link t_bdrus" href="<?php echo $context_path ?>/detail?id=<?php echo $gameSlides[$p]['id'] ?>">
                                                            <img class="card-img-top t_bdrus" src="<?php echo $context_path ?>/images/game/<?php echo $gameSlides[$p]['image'] ?>" alt="">
                                                    </a>
                                                    <?php } else { ?>
                                                        <a class="f-game-link t_bdrus" data-toggle = "modal" href = "#reg-modal-pro">
                                                            <img class="card-img-top t_bdrus" src="<?php echo $context_path ?>/images/game/<?php echo $gameSlides[$p]['image'] ?>" alt="">
                                                    </a>
                                                    <?php } ?>
                                                            
                                                    <div class="card-body mx-auto f-card-body mx-auto t_vv" style=" border-bottom-right-radius: 4px !important;border-bottom-left-radius: 4px !important; text-align:center">
                                                        <?php if(1==1){ ?>
                                                            <a class="f-game-link" href="<?php echo $context_path ?>/detail?id=<?php echo $gameSlides[$p]['id'] ?>"><b class="card-title game-feature-name"><?php echo $gameSlides[$p]['name_eng'] ?></b></a>
                                                        <?php } else { ?>
                                                            <a class="f-game-link" data-toggle = "modal" href = "#reg-modal-pro"><b class="card-title game-feature-name"><?php echo $gameSlides[$p]['name_eng'] ?></b></a>
                                                        <?php } ?>
                                                        
                                                    </div>

                                                    <?php if(1==1){ ?>
                                                        <a class="f-game-link ps_center" href="<?php echo $context_path ?>/detail?id=<?php echo $gameSlides[$p]['id'] ?>"><img class="icon_viewmore icon_viewmore_large" src="<?php echo $context_path ?>/img/btn_more_nor.png"></a>
                                                    <?php } else { ?>
                                                        <a class="f-game-link ps_center" data-toggle = "modal" href = "#reg-modal-pro"><img class="icon_viewmore icon_viewmore_large" src="<?php echo $context_path ?>/img/btn_more_nor.png"></a>
                                                    <?php } ?>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <?php if ($p == sizeof($gameSlides)-1) break; } ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="customNavigation">
                            <a id="prev_gamepro" class="owl-arrow"><i class='fa fa-chevron-left'></i></a>
                            <a id="next_gamepro" class="owl-arrow"><i class='fa fa-chevron-right'></i></a>
                        </div>
                    </div> -->


                    <h3 class="entry-heading" style="display: flex;">
                        <span style="font-weight: bold;">GOGAME</span>
                        <a style="font-style: italic; margin-left: auto; color: rgb(11, 162, 75);" href="<?php echo $context_path ?>/gogame">
                            <span style="font-size: 20px">MORE>></span>
                        </a>
                    </h3>
                    <div class="container">
                        <div id="gogame">
                            <?php for ($k=0; $k<$pageGoGame; $k++) {?>
                                <div id="item">
                                    <div class="row">
                                        <?php for ($i=0; $i<6; $i++) { $p=($k*6)+$i?>  
                                            <div class="col-sm-4 pdr_ip5 reset-padding-left col-6">
                                                <div class="container">
                                                    <div class="card f-card-game t_bdrus" style="margin-top: 15px;">
                                                        
                                                    <?php if(1==1){ ?>
                                                        <a class="f-game-link t_bdrus" href="<?php echo $context_path ?>/detail?id=<?php echo $goGames[$p]['id'] ?>">
                                                            <img class="card-img-top t_bdrus" src="<?php echo $context_path ?>/images/game/<?php echo $goGames[$p]['image'] ?>" alt="">
                                                        </a>
                                                    <?php } else { ?>
                                                        <a class="f-game-link t_bdrus" data-toggle = "modal" href = "#reg-modal-go">
                                                            <img class="card-img-top t_bdrus" src="<?php echo $context_path ?>/images/game/<?php echo $goGames[$p]['image'] ?>" alt="">
                                                        </a>
                                                    <?php } ?>

                                                                
                                                    <div class="card-body mx-auto f-card-body mx-auto t_vv" style=" border-bottom-right-radius: 4px !important;border-bottom-left-radius: 4px !important; text-align:center">                                            
                                                            
                                                        <?php if(1==1){ ?>
                                                            <a class="f-game-link" href="<?php echo $context_path ?>/detail?id=<?php echo $goGames[$p]['id'] ?>"><b class="card-title game-feature-name"><?php echo $goGames[$p]['name_eng'] ?></b></a>
                                                        <?php } else { ?>
                                                            <a class="f-game-link" data-toggle = "modal" href = "#reg-modal-go"><b class="card-title game-feature-name"><?php echo $goGames[$p]['name_eng'] ?></b></a>
                                                        <?php } ?>
                                                            
                                                        </div>

                                                        <?php if(1==1){ ?>
                                                            <a class="f-game-link ps_center" href="<?php echo $context_path ?>/detail?id=<?php echo $goGames[$p]['id'] ?>"><img class="icon_viewmore icon_viewmore_large" src="<?php echo $context_path ?>/img/btn_more_nor.png"></a>
                                                        <?php } else { ?>
                                                            <a class="f-game-link ps_center" data-toggle = "modal" href = "#reg-modal-go"><img class="icon_viewmore icon_viewmore_large" src="<?php echo $context_path ?>/img/btn_more_nor.png"></a>
                                                        <?php } ?>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if ($p == sizeof($goGames)-1) break; } ?>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="customNavigation">
                                <a id="prev_gogame" class="owl-arrow"><i class='fa fa-chevron-left'></i></a>
                                <a id="next_gogame" class="owl-arrow"><i class='fa fa-chevron-right'></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 padding-reset-left-right pc-view" id="f-bxh-select">
                        <div class="container t_ipab" style="padding:0 3px 0 12px;">
                            <div class="f_bxh t_bdrus" style="height:885px;">
                                <h5 class="text-center f_title_bxh t_bdtrus" style="margin-top: 15px">NEW GAME</h5>
                                <ul class="f_bxh_number mg_p" style="padding-left: 0px;">
                                    <?php foreach ($games as $i => $game) { ?>
                                        <li class="p_ipab" style="margin:3% 0 11px 0;width:100%; padding-left: 20px;">
                                            <div class="row f-top-icon pdt_ipad">
                                                <div class="col-xl-1 col-md-1">
                                                    <button class="f_icon_bxh icon_ipab f-top-icon mm_ipab" style="background-color: red;font-size:13px;"><?php echo $i + 1 ?></button>
                                                </div>
                                                <div class="col-xl-3 col-3 col-md-3" style="padding-left: 15px !important; padding-top: 0px !important;">
                                                    <div class="f-img-responsive-icon">
                                                        <a class="c_top-game-name" href="/detail?id=<?php echo $game['id'] ?>">
                                                            <img class="f-img-icon img_ipab" src="<?php echo $context_path ?>/images/game/<?php echo $game['image'] ?>" style="width:100%"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-8 col-8 col-md-8 pd_ipad reset-padding-left reset-padding-right">
                                                        <div class="text-left">
                                                            <p style="margin-bottom:5px"><a class="c_top-game-name" href="/detail?id=8"><b><?php echo $game['name_eng'] ?></b></a></p>
                                                            <span style="font-size:75%"><i></i><?php echo $game['category_eng'] ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </li>
                                            <hr>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <script type="text/javascript">
                var owl = $("#gamepro");
                $(document).ready(function(){
                    owl.owlCarousel({
                        items:1,
                        autoPlay:1800,
                        pagination: false,
                        loop:true,
                        stopOnHover:true,
                    })
                })
                $("#next_gamepro").click(function(){
                    owl.trigger('owl.next');
                })
                $("#prev_gamepro").click(function(){
                    owl.trigger('owl.prev');
                })
            </script>
            <script type="text/javascript">
                var owl_gogame = $("#gogame");
                $(document).ready(function(){
                    owl_gogame.owlCarousel({
                        items:1,
                        autoPlay:2000,
                        pagination: false,
                        loop:true,
                        stopOnHover:true
                    })
                })
                $("#next_gogame").click(function(){
                    owl_gogame.trigger('owl.next');
                })
                $("#prev_gogame").click(function(){
                    owl_gogame.trigger('owl.prev');
                })
            </script>

            <style type="text/css">
                .customNavigation{
                  text-align: center;
              }

              .owl-arrow {
                color: #52c770 !important;
                padding: 20px;

            }

            .owl-arrow:hover {
                cursor:pointer;
            }

        </style>


<!--modal register PRO-->
<div class="modal fade" id="reg-modal-pro" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="text-align: center">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">You have not subscribed to the GamePro package of the Game H5 service. Click register to play the game</h4>
            </div>
            <div class="modal-body">
               <a href="/register.php?pkg=GHD_GameH5_GamePro_Daily" class="register-button">SUBSCRIBE PRO</a>                            
            </div>
            <div class="modal-footer" style="text-align: center; margin: 0 auto;">
                <center><a style="color:white; background-color: darkred;" type="button" class="register-button" data-dismiss="modal">Exit</a></center>
            </div>
        </div>
    </div>
</div>

<!--modal register GO GAME-->
<div class="modal fade" id="reg-modal-go" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="text-align: center">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">You have not subscribed to the GoGame package of the Game H5 service. Click register to play the game</h4>
            </div>
            <div class="modal-body">
               <a href="/register.php?pkg=GHD_GameH5_GoGame_Daily" class="register-button">SUBSCRIBE GO GAME</a>                            
            </div>
            <div class="modal-footer" style="text-align: center; margin: 0 auto;">
                <center><a style="color:white; background-color: darkred;" type="button" class="register-button" data-dismiss="modal">Exit</a></center>
            </div>
        </div>
    </div>
</div>
<?php include './footer.php'; ?>
