<footer class="page-footer is-pc">
    <div class="container pc-view">
        <div class="row pd_list">
                <div class="col-md-8 col-12 reset-padding-left reset-padding-right">
                    <div class="footer1" style="right: 0;">
                            <div class="p1" style="padding-top: 2px;">
                                <p>Copyright@2021 By GHD</p>
                                <p>GHD INVESTMENT AND TECHNOLOGY JOINT STOCK COMPANY</p>
                                <p>6th floor, HL Tower, Lane 82 Duy Tan, Dich Vong Hau, Cau Giay, Hanoi</p>
                                <p>Playing more than 180 minutes a day will adversely affect health.</p>
                            </div>
                    </div>
                </div>
                <div class="col-md-4 col-12 reset-padding-left reset-padding-right" style="text-align:right;">
                  
                    <p class="contact-info">
                    <a  href="tel:Hotline:1777">Hotline: <span>1204</span>
                        <img src="<?php echo $context_path ?>/new-images-1/footer/FOOTER-ICO-PHONE.png" class="footer-ico">
                    </a>
                    </p>
                    <p class="contact-info">
                        <span class="footer-info">Viettel Cambodia Pte., Ltd</span>
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>



<footer class="is-mobile">
    <div class="footer-container">
    <div class="row">
            <div class="col-md-12 " style="text-align:center">
            <div>GHD INVESTMENT AND TECHNOLOGY JOINT STOCK COMPANY</div>            
            </div>
    </div>
</footer>
</body>
</html>
