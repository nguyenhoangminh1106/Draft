<?php

$site_name = "ZenH5 Portal";

$context_path = "http://gamezh5.com";

$pub_vt_path = "./key/go/PublicKeyVT.pem";

$pri_cp_path = "./key/go/PrivateKeyCP.pem";

$pub_cp_path = "./key/go/PublicKeyCP.pem";

$pub_vt_path_pro = "./key/pro/PublicKeyVT.pem";

$pri_cp_path_pro = "./key/pro/PrivateKeyCP.pem";

$pub_cp_path_pro = "./key/pro/PublicKeyCP.pem";

$pub_vt_path_pchum = "../key/pro/PublicKeyVT.pem";

$pri_cp_path_pchum = "../key/pro/PrivateKeyCP.pem";

$pub_cp_path_pchum = "../key/pro/PublicKeyCP.pem";

$domain = "http://html5.vitubi.com";

$secure_key = "ERSnr4g147K3RTrg";

$mps_url = "http://paymentgateway.metfone.com.kh/MPS/";
?>
