<?php

include './function.php';
include './config.php';
include './db.php';
include './mps-otp-process.php';

if(isset($_GET['msisdn'])){

    if(isset($_GET['pkg'])){

        $pkg_code = $_GET['pkg'];

        $type = $_GET['type'];

        $req_id = $_GET['req'];

        $otp = $_GET['otp'];

        $msisdn = $_GET['msisdn'];
        //$msisdn = '974579594';
        //$msisdn = '884656565';
        //$msisdn = '713482476';

        $cmd = 'REGISTER';

        if($pkg_code == 'GHD_GameH5_GamePro_Daily'){

                $price = '150000';

                if(is_reg_on_go_cycle($msisdn)){
                    $price = '0';
                }                

                if($req_id == '0'){                    
                    $req_id = round(microtime(true));
                }


                $input = "SUB=" . $pkg_code . "&MOBILE=" . $msisdn . "&CATE=CONTENT&ITEM=" . $pkg_code . "&SUB_CP=GHD&CONT=" . $pkg_code . "&PRICE=" . $price . "&REQ=" . $req_id . "&SOURCE=CLIENT&OTP=".$otp."&OTP_TYPE=". $type;

                $param = "PRO=GHD&SER=GHD_GameH5&SUB=" . $pkg_code . "&CMD=". $cmd;

                logger('[OTP INPUT] ' . $input);
                logger('[OTP PARAM] ' . $param);

                $aes_key = bin2hex(openssl_random_pseudo_bytes(16));

                $value_encrypt_aes = encrypt_aes($input, $aes_key);

                $value_with_key = 'value=' . $value_encrypt_aes . '&key=' . $aes_key;

                $encode = encrypt_rsa_pro($value_with_key);

                $sign = sign_data_pro($encode, $pri_cp_path_pro);

                $link = $mps_url . 'otp.html?' . $param . '&DATA=' . urlencode($encode) . '&SIG=' . $sign;

                //var_dump($link);

                $res_mps = file_get_contents($link);

                //var_dump($res_mps);

                //exit();

                parse_str($res_mps, $output);

                $decode = otp_res_process($output['DATA'], $output['SIG']);

                if($msisdn != '855null'){

                    logger('[OTP RES] ' + json_encode($decode));

                    if($decode['CMD'] == 'REGISTER'){
                        //xu ly dang ky qua OTP
                        if($decode['RES'] == '0'){
                            //đăng ký thành công
                            initSub($msisdn, $pkg_code);                        
                            insertRegister($msisdn, $pkg_code);                            
                        }
                    }
                }
                header('Content-type: application/json');
                echo json_encode($decode);
                exit();            
        }
        header('Location: ' . $link);
        exit();
    }
}else{
    echo 'error';
    exit();
}
?>
