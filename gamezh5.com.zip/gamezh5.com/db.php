<?php

$con = mysqli_connect("127.0.0.1:3306", "zenh5", "zenh5@123", "zenh5");
mysqli_set_charset($con, "utf8");

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//$memcache = memcache_connect('localhost', 11211);
$memcache = false;

function getGameById($id) {
    $id = urlencode($id);
    global $con;
    global $memcache;
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        t1.name_eng as category_eng,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.summary,
        t2.summary_eng,
        t2.image,
        t2.age,
        t3.content,
        t3.content_eng
      FROM
        article_type AS t1,
        article AS t2,
        article_detail AS t3  
      WHERE 
      t1.id = t2.type 
      AND t2.id = t3.id
	  AND t2.type != 99
      AND t2.status in (0,88)
      AND t2.id = {$id}";
    if ($memcache) {
        $key = "h5game_eng_getGameById_{$id}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            $data = @mysqli_fetch_array($sql_query);
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        if (!$sql_query) {
            die('Invalid query: ' . mysql_error());
        }
        return @mysqli_fetch_array($sql_query);
    }
}

function getListGameHome() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        t1.name_eng as category_eng,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.status in (0,88)
      ORDER BY RAND()";
    if ($memcache) {
        $key = "h5game_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

function getListGameHomeHtml5() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        t1.name_eng as category_eng,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.pkg = 1
      AND t2.status in(0,88)
      ORDER BY RAND()";
    if ($memcache) {
        $key = "h5game_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

function getTopGame() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        t1.name_eng as category_eng,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.status in (0,88)
      ORDER BY RAND()
      LIMIT 9";
    if ($memcache) {
        $key = "h5game_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

function getTopGameHtml5() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        t1.name_eng as category_eng,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.status in (0,88)
      ORDER BY RAND()
      LIMIT 9";
    if ($memcache) {
        $key = "h5game_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

function getSlideGame() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.status in (0,88)
      ORDER BY RAND()
      LIMIT 200";
    if ($memcache) {
        $key = "h5game_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

// get list gamePro
function getSlideGameHtml5() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.pkg = 1
      AND t2.status in (0,88)
      ORDER BY RAND()";
    if ($memcache) {
        $key = "h5game_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

// get list gogame
function getGoGameHtml5() {
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT
        t2.id,
        t2.name,
        t2.name_eng,
        t2.intro,
        t2.intro_eng,
        t1.name AS category,
        (FLOOR( 1 + RAND( ) * 1000 )) AS viewed,
        t2.image
      FROM
        article_type AS t1,
        article AS t2
      WHERE t1.id = t2.type AND t2.type != 99
      AND t2.pkg = 2
      AND t2.status in (0,88)
      ORDER BY id";
    if ($memcache) {
        $key = "h5gogame_eng_getListNews_{$a}_{$b}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}


function getSystemArticle($type) {
    $type = urlencode($type);
	if ($type == 'guide') {
		$id = 167;
	} else if ($type == 'intro') {
		$id = 169;
	} else if ($type == 'promo') {
		$id = 171;
	}
    global $con;
    global $memcache;
    $sql = "SELECT
        t3.content
      FROM
        article_detail AS t3  
      WHERE t3.id = {$id}";
    if ($memcache) {
        $key = "h5game_eng_getSystemArticle_{$id}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            $data = @mysqli_fetch_array($sql_query);
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        if (!$sql_query) {
            die('Invalid query: ' . mysql_error());
        }
        return @mysqli_fetch_array($sql_query);
    }
}

//=================Xử lý nghiệp vụ VAS

function isSubs($msisdn) {
    $msisdn = (int) $msisdn;
    global $con;
    global $memcache;
    $sql = "SELECT 1 FROM user_subscriber WHERE msisdn = '{$msisdn}' AND TYPE = 1 AND STATUS = 0";
    if ($memcache) {
        $key = "lucky_getuser_{$msisdn}";
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            $data = @mysqli_fetch_array($sql_query);
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        if (!$sql_query) {
            die('Invalid query: ' . mysqli_error());
        }
        return @mysqli_fetch_array($sql_query);
    }
}

function login($user, $pass) {
    global $con;
    $user = addslashes(mysqli_real_escape_string($con, $user));
    $user = convert_phone($user);
    $pass = addslashes(mysqli_real_escape_string($con, $pass));

    $sql = "SELECT msisdn FROM user_account WHERE msisdn = '{$user}' AND PASSWORD = '{$pass}'";
    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }
    return @mysqli_fetch_array($sql_query);
}

function check_register($user) {
    global $con;
    $user = addslashes(mysqli_real_escape_string($con, $user));
    $user = convert_phone($user);

    $sql = "SELECT pkg_code, create_date FROM user_subscriber WHERE TYPE = 1 AND STATUS = 0 AND msisdn = '{$user}'";

    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }
    return @mysqli_fetch_array($sql_query);
}

function convert_phone($msisdn) {
    if (strpos($msisdn, "0") === 0) {
        $msisdn = "855" . substr($msisdn, 1);
    }
    if (strpos($msisdn, "855") === 0) {
        
    } else {
        $msisdn = "855" . $msisdn;
    }
    return $msisdn;
}

function getReport() {
    date_default_timezone_set('UTC');
    global $con;
    global $memcache;
    $re = array();
    $sql = "SELECT 
            DATE_FORMAT(report_date, '%d/%m/%Y') AS report_date,
            (SELECT 
              SUM(t2.total_subs) 
            FROM
              report AS t2 
            WHERE t2.report_date <= t1.report_date) AS total_subs,
            SUM(total_subs) AS daily_subs,
            SUM(register) AS register,
            SUM(cancel) AS cancel,
            SUM(reg_income) AS reg_income,
            SUM(renew_income) AS renew_income,
            SUM(renew_suc) AS renew_suc,            
            (SUM(renew_income) + SUM(reg_income)) AS total_income
          FROM
            report AS t1 
          WHERE 
          MONTH(t1.report_date) = MONTH(DATE_ADD(CURDATE(), INTERVAL - 1 DAY)) AND
          YEAR(t1.report_date) = YEAR(CURDATE())
          GROUP BY t1.report_date 
          ORDER BY t1.report_date DESC";
    if ($memcache) {
        $key = "getReport_" . date("dmY");
        $data = $memcache->get($key);
        if ($data) {
            return $data;
        } else {
            $sql_query = @mysqli_query($con, $sql);
            while ($row = mysqli_fetch_array($sql_query)) {
                array_push($re, $row);
            }
            $data = $re;
            $memcache->set($key, $data, 0, 600);
            return $data;
        }
    } else {
        $sql_query = @mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($sql_query)) {
            array_push($re, $row);
        }
        return $re;
    }
}

function initSub($msisdn, $pkg_code) {
    global $con;    
    $query = "UPDATE user_subscriber SET STATUS = 1 WHERE msisdn = ? and pkg_code = '{$pkg_code}' AND STATUS = 0";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $msisdn);
    $stmt->execute();
}

function insertRegister($msisdn , $pkg_code, $partner) {
    global $con;    
    $query = "INSERT INTO user_subscriber (pkg_code, msisdn, partner, type, status, channel, create_date) VALUES('{$pkg_code}', ?, '{$partner}', 1, 0, 'WAP', NOW())";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $msisdn);
    $stmt->execute();
}

function check_partner($user) {
    global $con;
    $user = addslashes(mysqli_real_escape_string($con, $user));
    $user = convert_phone($user);

    $sql = "SELECT partner FROM user_subscriber WHERE msisdn = '{user}' AND STATUS = 0 ORDER BY id DESC LIMIT 1";

    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }
    return @mysqli_fetch_array($sql_query);
}

function insertCancel($msisdn , $pkg_code) {
    global $con;    
    $query = "INSERT INTO user_subscriber (pkg_code, msisdn, partner, type, status, channel, create_date) VALUES('{$pkg_code}', ?, 'WAP', 2, 0, 'WAP', NOW())";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $msisdn);
    $stmt->execute();
}

function insertReportReg($partner, $reg_income) {
    global $con;    
    $query = "INSERT INTO report (report_date, partner, total_subs, register, reg_income) VALUES (CURDATE(), ?, 1, 1, {$reg_income}) ON DUPLICATE KEY UPDATE total_subs = total_subs + 1, register = register + 1, reg_income = reg_income + {$reg_income}";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $partner);
    $stmt->execute();
}

function insertReportCancel($partner) {
    global $con;    
    $query = "INSERT INTO report (report_date, partner, total_subs, cancel) VALUES (CURDATE(), ?, -1, 1) ON DUPLICATE KEY UPDATE total_subs = total_subs - 1, cancel = cancel + 1";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $partner);
    $stmt->execute();
}

function get_active($user) {
    global $con;
    $user = addslashes(mysqli_real_escape_string($con, $user));
    $user = convert_phone($user);
    $re = array();
    $sql = "SELECT pkg_code, create_date FROM user_subscriber WHERE TYPE = 1 AND STATUS = 0 AND msisdn = '{$user}'";

    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }

    while ($row = mysqli_fetch_array($sql_query)) {
        array_push($re, $row);
    }

    return $re;
}

function is_reg_on_go_cycle($user) {
    global $con;
    $user = addslashes(mysqli_real_escape_string($con, $user));
    $user = convert_phone($user);
    $re = array();
    $sql = "SELECT 1 FROM user_subscriber WHERE msisdn = '{$user}' AND pkg_code = 'GHD_GameH5_GoGame_Daily' AND create_date >= (NOW() - INTERVAL 1 DAY) LIMIT 1";

    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }

    if (mysqli_num_rows($sql_query) > 0) {
        return true;
    }else{
        return false;
    }
}

function is_reg_on_pro_cycle($user) {
    global $con;
    $user = addslashes(mysqli_real_escape_string($con, $user));
    $user = convert_phone($user);
    $re = array();
    $sql = "SELECT 1 FROM user_subscriber WHERE msisdn = '{$user}' AND pkg_code = 'GHD_GameH5_GamePro_Daily' AND create_date >= (NOW() - INTERVAL 7 DAY) LIMIT 1";

    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }

    if (mysqli_num_rows($sql_query) > 0) {
        return true;
    }else{
        return false;
    }

}

function get_partner($package_code) {
    global $con;
    $re = array();
    $sql = "select * from partner_config where package_code =  '{$package_code}' ";

    $sql_query = @mysqli_query($con, $sql);
    if (!$sql_query) {
        die('Invalid query: ' . mysqli_error());
    }

    while ($row = mysqli_fetch_array($sql_query)) {
        array_push($re, $row);
    }

    return $re;
}

?>
