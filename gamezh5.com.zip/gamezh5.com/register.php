<?php

include './function.php';
include './config.php';
include './db.php';


    if(isset($_GET['pkg'])){

        $partner = 'WAP';

        $pkg_code = $_GET['pkg'];

        if(isset($_COOKIE['msisdn'])){
            $msisdn = $_COOKIE["msisdn"];
        }

        if(isset($_GET['msisdn'])){
            $msisdn = $_GET['msisdn'];
        }

        if($pkg_code == 'GHD_GameH5_GoGame_Daily'){

            $price = '100000';

            if(is_reg_on_go_cycle($msisdn)){
                $price = '0';
            }
            
            $req_id = $pkg_code .'.'. $partner .'.'. round(microtime(true));            

            $input = "SUB=" . $pkg_code . "&MOBILE=" . $msisdn . "&CATE=CONTENT&ITEM=" . $pkg_code . "&SUB_CP=GHD&CONT=" . $pkg_code . "&PRICE=" . $price . "&REQ=" . $req_id . "&SOURCE=WAP";

            $param = "PRO=GHD&SER=GHD_GameH5&SUB=" . $pkg_code . "&CMD=REGISTER";

            $aes_key = bin2hex(openssl_random_pseudo_bytes(16));

            $value_encrypt_aes = encrypt_aes($input, $aes_key);

            $value_with_key = 'value=' . $value_encrypt_aes . '&key=' . $aes_key;

            $encode = encrypt_rsa($value_with_key);

            $sign = sign_data($encode, $pri_cp_path);

            $link = $mps_url . 'charge.html?' . $param . '&DATA=' . urlencode($encode) . '&SIG=' . $sign;

        }else{

            $price = '150000';

            if(is_reg_on_pro_cycle($msisdn)){
                $price = '0';
            }
            
            $req_id = $pkg_code .'.'. $partner .'.'. round(microtime(true));

            $input = "SUB=" . $pkg_code . "&MOBILE=" . $msisdn . "&CATE=CONTENT&ITEM=" . $pkg_code . "&SUB_CP=GHD&CONT=" . $pkg_code . "&PRICE=" . $price . "&REQ=" . $req_id . "&SOURCE=WAP";

            $param = "PRO=GHD&SER=GHD_GameH5&SUB=" . $pkg_code . "&CMD=REGISTER";

            $aes_key = bin2hex(openssl_random_pseudo_bytes(16));

            $value_encrypt_aes = encrypt_aes($input, $aes_key);

            $value_with_key = 'value=' . $value_encrypt_aes . '&key=' . $aes_key;

            $encode = encrypt_rsa_pro($value_with_key);

            $sign = sign_data_pro($encode, $pri_cp_path_pro);

            $link = $mps_url . 'charge.html?' . $param . '&DATA=' . urlencode($encode) . '&SIG=' . $sign;
        }

        header('Location: ' . $link);
        exit();
    }
header('Location: /');
?>
