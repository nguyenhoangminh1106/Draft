<?php
/*$dbhost = "localhost"; 
$dblogin = "ghdc"; 
$dbpassword = "ghdc@123"; 
$dbdatabase = "h5game"; 
$connection = mysql_connect($dbhost, $dblogin, $dbpassword); 
        @mysql_select_db($dbdatabase); 
        mysql_query("SET NAMES 'utf8'");
if(!$connection)
  die ("Can not connect to the database: <br />".mysql_error());		*/
// $connect = array('localhost', 'ghdc', 'ghdc@123', 'h5game');
	
// 	$base = $db = new mysqli($connect['0'], $connect['1'], $connect['2'], $connect['3']);
	
// 	         $base -> query("SET NAMES 'UTF8'"); 
				 
// 				 if($base -> connect_errno) die('ERROR -> '.$base -> connect_error);		


// $assoc=$db->query("SELECT * FROM `play_session` WHERE `score`>'0'");
// echo "TEST2<br/>";
// while($assoc11 = $assoc->fetch_assoc()) {
// 	echo "IDgame: ".$assoc11['game_id']." - SĐT: ".$assoc11['msisdn']." - Điểm: ".$assoc11['score']."<br/>";
// }

/*
$servername = "localhost";
$database = "h5game";
$username = "ghdc";
$password = "ghdc@123";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection

if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
mysqli_close($conn);*/
/*$today = date('Y-m-d H:i:s', time());
$db->query("INSERT INTO `play_session` (`msisdn`, `game_id`, `start_time`, `end_time`, `score`) VALUES ('123456789', '12', '".$today."','".$today."','11')");
//$db->query("INSERT INTO `play_session` (`msisdn`, `game_id`, `start_time`, `end_time`, `score`) VALUES ('123456', '12', '0','0','1')");
$assoc=mysqli_query("SELECT * FROM `play_session` WHERE `score`>'0'");
echo "TEST<br/>";
while($assoc11 = mysqli_fetch_assoc($assoc)) {
	echo "SĐT: ".$assoc11['msisdn']." - Điểm: ".$assoc11['score']."<br/>";
}*/

include './function.php';
include './config.php';
include './db.php';

$partner = check_partner('855974579594');
var_dump($partner['partner']);
exit();
?>