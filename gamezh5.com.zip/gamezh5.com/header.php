
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name = "format-detection" content = "telephone=no">

        <meta property="og:title" content="ZenH5 | Entertainment game portal on HTML5 platform">
        <meta property="og:type" content="ZenH5 | Entertainment game portal on HTML5 platform">
        <meta property="og:description" content="ZenH5 | Entertainment game portal on HTML5 platform">
        <meta property="og:url" content="http://gamezh5.com/">
        <html prefix="og:http://gamezh5.com/">
        <meta property="og:image" content="<?php echo $context_path ?>/images/banner/slide-2.jpg">
        <meta property="og:image:width" content="477">
        <meta property="og:image:height" content="250">
        <meta property="og:site_name" content="ZenH5">

        <title><?php echo $site_name ?></title>
        <link href="<?php echo $context_path ?>/img/favicon.ico" rel="shortcut icon">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />
        <link rel="stylesheet" href="<?php echo $context_path ?>/plugin/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/popup.css">

        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script> 

        <link rel="stylesheet" href="<?php echo $context_path ?>/plugin/slider/flexslider.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/plugin/lity/lity.min.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8/dist/sweetalert2.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@8/dist/sweetalert2.min.css" id="theme-styles">
        <script src="<?php echo $context_path ?>/plugin/slider/jquery.flexslider-min.js"></script>
        <script src="<?php echo $context_path ?>/plugin/lity/lity.min.js"></script>

        <link rel="canonical" href="http://gamezh5.com/">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/mobile-detect/1.4.3/mobile-detect.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.4.2/jquery.twbsPagination.min.js" integrity="sha256-swvs/72H2JZrIbyDdMskQv2t0bpTO5tgJOWVMBgZq6U=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/footer.css">
        
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/common.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/main.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/header.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/game.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/owl.carousel.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/owl.theme.css">
        <link rel="stylesheet" href="<?php echo $context_path ?>/css/owl.transitions.css">

        <link rel="stylesheet" href="<?php echo $context_path ?>/css/custom.css">

        <script src="<?php echo $context_path ?>/js/index.js"></script>
        <script src="<?php echo $context_path ?>/js/listGame.js"></script>

        <script src="<?php echo $context_path ?>/js/jquery-3.6.0.min.js"></script>
        <script src="<?php echo $context_path ?>/js/owl.carousel.js"></script>
        <!-- <script src="<?php echo $context_path ?>/js/owl.carousel.min.js"></script> -->
