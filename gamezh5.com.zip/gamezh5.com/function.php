<?php

include 'config.php';

function header_exists($name) {
    $headers = array();
    foreach ($_SERVER as $key => $value) {
        if (substr($key, 0, 5) <> 'HTTP_') {
            continue;
        }
        $header = str_replace(' ', '-', strtolower(str_replace('_', ' ', strtolower(substr($key, 5)))));
        $headers[$header] = $value;
    }
    return array_key_exists($name, $headers);
}

function aes_encrypt($data, $key) {
    $method = 'AES-128-ECB';
    $ivSize = openssl_cipher_iv_length($method);
    $iv = openssl_random_pseudo_bytes($ivSize);
    $encrypted = openssl_encrypt($data, $method, $key, 1, $iv);
    $encrypted = base64_encode($iv . $encrypted);

    return $encrypted;
}

function aes_decrypt($data, $key) {
    $method = 'AES-128-ECB';
    $data = base64_decode($data);
    $ivSize = openssl_cipher_iv_length($method);
    $iv = substr($data, 0, $ivSize);
    //$data = openssl_decrypt(substr($data, $ivSize), $method, $key, OPENSSL_RAW_DATA, $iv);
    $data = openssl_decrypt(substr($data, $ivSize), $method, $key, 1, $iv);
    return $data;
}

function logger($log_msg) {
    date_default_timezone_set("Asia/Bangkok");
    $log_path = "/u01/game/website/html5.fzone.vn/log/mps";
    $log_msg = "[" . date('Y-m-d H:i:s') . "] " . $log_msg;
    $log_file_data = $log_path . '/log_' . date('Ymd') . '.log';
    file_put_contents($log_file_data, $log_msg . "\n", FILE_APPEND);
}

function logger_dao_vang($log_msg) {
    date_default_timezone_set("Asia/Bangkok");
    $log_path = "/u01/game/website/html5.fzone.vn/log/daovang";
    $log_msg = "[" . date('Y-m-d H:i:s') . "] " . $log_msg;
    $log_file_data = $log_path . '/log_' . date('Ymd') . '.log';
    file_put_contents($log_file_data, $log_msg . "\n", FILE_APPEND);
}

function hidden_phone_end($msisdn) {
    return "0" . substr($msisdn, 2, (strlen($msisdn) - 6)) . "xxxx";
}

//84931711469
function hidden_phone($msisdn) {
    return "0".substr($msisdn, 2, 2). "xxxx". substr($msisdn, 8, 3);
}

function to_phone($msisdn) {
    return "0" . substr($msisdn, 2, strlen($msisdn) - 2);
}

//Get the client IP address
function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function getRequestHeaders() {
    $headers = array();
    foreach ($_SERVER as $key => $value) {
        if (substr($key, 0, 5) <> 'HTTP_') {
            continue;
        }
        $header = str_replace(' ', '-', strtolower(str_replace('_', ' ', strtolower(substr($key, 5)))));
        $headers[$header] = $value;
    }
    return $headers;
}

function to_ascii($str) {
    $str = str_replace(" ", "-", str_replace("&*#39;", "", $str));
    $str = str_replace("--", "", $str);
    $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
    $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
    $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
    $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
    $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
    $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
    $str = preg_replace("/(đ)/", 'd', $str);
    $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
    $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
    $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
    $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
    $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
    $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
    $str = preg_replace("/(Đ)/", 'D', $str);
    $str = preg_replace('/[^A-Za-z0-9\-]/', '', $str);
    $str = strtolower($str);
    return $str;
}

//=====================RSA for PRO package
function encrypt_rsa_pro($data) {
    global $pub_vt_path_pro;
    $pub_key_vt_pro = file_get_contents($pub_vt_path_pro);
    if (openssl_public_encrypt($data, $encrypted, $pub_key_vt_pro))
        $data = base64_encode($encrypted);
    else
        $data = '';
    return $data;
}

function decrypt_rsa_pro($data) {
    global $pri_cp_path_pro;
    $pri_key_cp_pro = file_get_contents($pri_cp_path_pro);
    if (openssl_private_decrypt(base64_decode($data), $decrypted, $pri_key_cp_pro))
        $data = $decrypted;
    else
        $data = '';

    return $data;
}

function sign_data_pro($data, $pri_cp_path_pro) {
    $privkeyCP = file_get_contents($pri_cp_path_pro);
    openssl_sign($data, $signature, $privkeyCP);
    $sign = urlencode(base64_encode($signature));
    return $sign;
}

//=====================RSA Encrypt/Decrypt

function encrypt_rsa($data) {
    global $pub_vt_path;
    $pub_key_vt = file_get_contents($pub_vt_path);
    if (openssl_public_encrypt($data, $encrypted, $pub_key_vt))
        $data = base64_encode($encrypted);
    else
        $data = '';
    return $data;
}

function decrypt_rsa($data) {
    global $pri_cp_path;
    $pri_key_cp = file_get_contents($pri_cp_path);
    if (openssl_private_decrypt(base64_decode($data), $decrypted, $pri_key_cp))
        $data = $decrypted;
    else
        $data = '';

    return $data;
}

function sign_data($data, $pri_cp_path) {
    $privkeyCP = file_get_contents($pri_cp_path);
    openssl_sign($data, $signature, $privkeyCP);
    $sign = urlencode(base64_encode($signature));
    return $sign;
}

//====================AES Encrypt/Decrypt

function encrypt_aes($data, $key) {
    $method = 'AES-128-ECB';
    $ivSize = openssl_cipher_iv_length($method);   
    $iv = openssl_random_pseudo_bytes($ivSize);

    $encrypted = base64_encode(openssl_encrypt($data, $method, pack("H*", $key), 1, $iv));

    return $encrypted;
}

function decrypt_aes($data, $key) {
    $method = 'AES-128-ECB';
    $ivSize = openssl_cipher_iv_length($method);
    $iv = openssl_random_pseudo_bytes($ivSize);

    $decrypted = openssl_decrypt(base64_decode($data), $method, pack("H*", $key), 1, $iv);

    return $decrypted;
}


//=======================Mã hóa dành cho PCHUM
function encrypt_rsa_pchum($data) {
    global $pub_vt_path_pchum;
    $pub_key_vt_pchum = file_get_contents($pub_vt_path_pchum);
    if (openssl_public_encrypt($data, $encrypted, $pub_key_vt_pchum))
        $data = base64_encode($encrypted);
    else
        $data = '';
    return $data;
}

function decrypt_rsa_pchum($data) {
    global $pri_cp_path_pchum;
    $pri_key_cp_pchum = file_get_contents($pri_cp_path_pchum);
    if (openssl_private_decrypt(base64_decode($data), $decrypted, $pri_key_cp_pchum))
        $data = $decrypted;
    else
        $data = '';

    return $data;
}

function sign_data_pchum($data, $pri_cp_path_pchum) {
    $privkeyCP = file_get_contents($pri_cp_path_pchum);
    openssl_sign($data, $signature, $privkeyCP);
    $sign = urlencode(base64_encode($signature));
    return $sign;
}

?>