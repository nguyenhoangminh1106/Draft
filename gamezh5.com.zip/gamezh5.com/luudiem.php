<?php
$connect = array('localhost', 'ghdc', 'ghdc@123', 'h5game');
	
	$base = $db = new mysqli($connect['0'], $connect['1'], $connect['2'], $connect['3']);
	
	         $base -> query("SET NAMES 'UTF8'"); 
				 
				 if($base -> connect_errno) die('ERROR -> '.$base -> connect_error);		


$diem = intval(abs($_POST['s']));
if(isset($_POST['data']) && $diem>0) {
	
	$idg = intval($_POST['i']);
	$ten = intval(abs($_POST['dt']));
	/*if($diem>0 && $ten > 0) {
		$diemluu = $ten."|".$diem;
		 $level = file('data/luudiem'.$idg.'.dat');
		$level22 = explode("*",$level[0]);
		$count1 = count($level22);
		$aa = 0;
		if($count1>100) $count1=100;
		for($i=0;$i<$count1;$i++) {
				if($i==0) {
					$dkl = explode("|",$level22[$i]);
					$lis = $level22[$i];
					if($diem>intval($dkl[1]) && $aa==0) {
						if($ten == $dkl[0]) {
							$lis = $diemluu;
						}
						else $lis = $diemluu."*".$level22[$i];
						$aa = 1;
					}
				}
				else {
					$dkl = explode("|",$level22[$i]);
					if($diem>intval($dkl[1]) && $aa==0) {
						if($ten == $dkl[0]) {
							$lis .= "*".$diemluu;
						} else {
						$lis .= "*".$diemluu."*".$level22[$i];
						
						}
						$aa=1;
					}
					else {
						if($aa==1 && $ten == $dkl[0]) 
						$lis .= '';
						else {	
						$lis .= '*'.$level22[$i];
						if($ten == $dkl[0])  $aa=1;
						}
					}
					
				}
			
		}
		  $file = @fopen('data/luudiem'.$idg.'.dat', 'w');
			if (!$file)
				echo "Mở file không thành công";
			else {
				if($diem>0 && $ten!='') {
					
						$data = $lis;
					
						fwrite($file, $data);
						fclose($file);
					
				}
			}
	}*/
	$today = date('Y-m-d H:i:s', time());
	$db->query("INSERT INTO `play_session` (`msisdn`, `game_id`, `start_time`, `end_time`, `score`) VALUES ('".$ten."', '".$idg."', '".$today."','".$today."','".$diem."')");
}
?>