<?php
$connect = array('localhost', 'ghdc', 'ghdc@123', 'h5game');
$base = $db = new mysqli($connect['0'], $connect['1'], $connect['2'], $connect['3']);
$base -> query("SET NAMES 'UTF8'"); 
if($base -> connect_errno) die('ERROR -> '.$base -> connect_error);

if(isset($_GET['game'])) {
	$idg = intval($_GET['game']);
	$num = 0;
	if(isset($_GET['leng'])) {
		$num = intval($_GET['leng']);
	}
	$assoc=$db->query("SELECT * FROM `bxh` WHERE `score`>'0' AND `game_id`=".$idg." ORDER BY `score` DESC LIMIT ".$num.", 10");
	
	$i = 0;
	$textt2 ='';
	$j = $num + 1;
	while($assoc11 = $assoc->fetch_assoc()) {
		$cuoi = substr($assoc11['msisdn'], -3, 3);
		$dau = substr($assoc11['msisdn'], 0, 1);
		$sdt = "0".$dau."*****".$cuoi;
		$return1 =  array("name"=>$sdt,"diem"=>$assoc11['score']);
		
		$textt2 .= '<li class="no'.$j.'"><div class="col0"><span class="rank">'.$j.'</span></div><div class="col2"><div class="info"><p class="name">'.$sdt.'</p></div></div><div class="col3"><p class="score">'.$assoc11['score'].'</p></div></li>';
		$j++;
	}
	echo $textt2;
}

?>