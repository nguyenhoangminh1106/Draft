<?php
include './db.php';
include './header.php';
include './menu.php';
?>

<?php
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    $game = getGameById($id);
} else {
    header('Location:/404.php');
    exit;
}
?>
<section class="menu-banner-top"></section>
<section style="background-color: rgba(204,204,204, 0.2);">
    <div class="game">
        <div class="container resetp_ipad padding: 0">
            <div class="row list_game f-top-icon" style="padding-bottom:0px;">
                <div class="col-xl-12 col-md-12 col-lg-12 col-12" style="text-align: center">
                    <?php if ($game['content_eng'] != '') { ?>
                        <iframe src="http://gamezh5.com/<?php echo $game['content_eng']; ?>/" class="iframe" frameborder="0" scrolling="no"></iframe>
                    <?php } else { ?>
                        <center style="padding-top: 20px"><h1>This game is not available in English</h1></center>
                    <?php } ?>
                </div>
            </div>	
        </div>
    </div>
</section>
<style>
    @media only screen and (min-width: 600px) {
        .iframe{
            margin-top: 1px;
            width:60%;
            height:calc(100vh - 73px);
        }
    }

    @media only screen and (max-width: 600px) {
        header{
            display: none;
        }

        .menu-banner-top{
            display: none;
        }

        .iframe{
            margin-top: 1px;
            width:100%;
            height:640px; 
        }

    }
</style>
