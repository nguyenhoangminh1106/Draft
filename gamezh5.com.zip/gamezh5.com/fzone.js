var page_leng = 0;
function updateShare(score,i,dt) {
	i = Math.floor(i);
	$.ajax({
		type: 'POST',
		url: '/luudiem.php',
		data: 'data=luudiem&s='+score+'&i='+i+'&dt='+dt,
		success:function(result){
		}
	});
	page_leng = 0;
	$.ajax({url: "/bxh.php?game="+i, success: function(result){
		var textt='';
		var j=0;
		var ra;
		var tuoi;
		var diem1;
		var ngay;
		var check = 0;
		var linkgame=i;
		jQuery("body").append('<div style="" id="rank_layout"><div class="panel_wrap"><section class="panel"><header><h1 class="rank_tit">TOP RANKING</h1></header><div class="my_section"><div class="top"><div class="txt_area">New score: '+score+'</div></div></div><div class="rank_wrap"><div id="wrapper" style="overflow-y: scroll;"><div id="scroller" class="rank_section" style="transition-property: transform; transform-origin: 0px 0px; transform: translate(0px, 0px) translateZ(0px);"><ul id="list_rank_li">'+result+'</ul></div><div style="position: absolute; z-index: 100; bottom: 2px; top: 2px; right: 1px; pointer-events: none; transition-property: opacity; opacity: 1;"><div style="position: absolute; z-index: 100; background: padding-box padding-box rgba(0, 0, 0, 0.5); border: 1px solid rgba(255, 255, 255, 0.9); box-sizing: border-box; width: 100%; border-radius: 3px; pointer-events: none; transition-property: transform; transition-timing-function: cubic-bezier(0.33, 0.66, 0.66, 1); transform: translate(0px, 0px) translateZ(0px); height: 68px;"></div></div></div></div><footer><div class="btns"><a onclick="dongluudiem()" class="btn btn_play">Close</a><a onclick="more_game_li('+linkgame+')" class="btn btn_vs">More</a></div></footer></section></div></div>');
	 }});
	
}
function more_game_li(i) {
	page_leng += 10;
	$.ajax({url: "/bxh.php?game="+i+"&leng="+page_leng, success: function(result){
		jQuery("#list_rank_li").append(result);
	 }});
}
function afkmobi() {
	var afkmobi = false;
	jQuery.ajax({
		type: 'POST',
		url: '/luudiem.php',
		data: 'data=afk',
		success:function(result){
			xemquangcao()===true;
		}
	});
}
function dongluudiem() {
	$( "#myModal" ).remove();
	$( "#rank_layout" ).remove();
}

function luudiem(score) {
	var diem = $("#usern").val();
	$.ajax({
		type: 'POST',
		url: '/luudiem.php',
		data: 'data='+diem+'&s='+score,
		success:function(result){
		}
	});
}

function dangnhap() {
	var user = $("#user").val();
	var id = $("#idg").val();
	$.ajax({
		type: 'POST',
		url: '/luudiem.php',
		data: 'data=dangnhap&user='+user+'&id='+id,
		success:function(result){
			if(result=='ok') {
				$(".ghichu").html("Đăng nhập thành công");
				setTimeout(function(){ dongluudiem() }, 1500);
			} else {
				$(".ghichu").html(result);
			}
		}
	});
}
jQuery("head").append("<link rel='stylesheet' href='/score.min.css?v=30' type='text/css'>");

