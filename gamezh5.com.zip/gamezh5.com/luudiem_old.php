<?php
if(isset($_POST['data'])) {
	$diem = intval($_POST['s']);
	$idg = intval($_POST['i']);
	$ten = intval(abs($_POST['dt']));
	//$ten =  $_SESSION['pspt_user'];
	if($diem>0) {
		//$_SESSION['diem_luu'] = $diem;
		//echo $ten."|".$idg."|".$diem;
		$diemluu = $ten."|".$diem;
		 $level = file('data/luudiem'.$idg.'.dat');
		$level22 = explode("*",$level[0]);
		$count1 = count($level22);
		$aa = 0;
		if($count1>100) $count1=100;
		for($i=0;$i<$count1;$i++) {
			
			
				if($i==0) {
					$dkl = explode("|",$level22[$i]);
					$lis = $level22[$i];
					if($diem>intval($dkl[1]) && $aa==0) {
						if($ten == $dkl[0]) {
							$lis = $diemluu;
						}
						else $lis = $diemluu."*".$level22[$i];
						$aa = 1;
					}
				}
				else {
					$dkl = explode("|",$level22[$i]);
					if($diem>intval($dkl[1]) && $aa==0) {
						if($ten == $dkl[0]) {
							$lis .= "*".$diemluu;
						} else {
						$lis .= "*".$diemluu."*".$level22[$i];
						
						}
						$aa=1;
					}
					else {
						if($aa==1 && $ten == $dkl[0]) 
						$lis .= '';
						else {	
						$lis .= '*'.$level22[$i];
						if($ten == $dkl[0])  $aa=1;
						}
					}
					
				}
			
		}
		  $file = @fopen('data/luudiem'.$idg.'.dat', 'w');
			if (!$file)
				echo "Mở file không thành công";
			else {
				if($diem>0 && $ten!='') {
					
						$data = $lis;
					
						fwrite($file, $data);
						fclose($file);
					
				}
			}
	}
	
}
?>