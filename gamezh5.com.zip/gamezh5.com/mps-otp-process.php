<?php 

function otp_res_process($data_encrypted, $sign){

    $data = str_replace(' ', '+', $data_encrypted);

    $sig = urldecode($sign);    
    
    $data_decrypt = decrypt_rsa($data);

    if($data_decrypt == null){
        $data_decrypt = decrypt_rsa_pro($data);
    }   

    parse_str($data_decrypt, $output);

    $value = str_replace(' ', '+', $output['VALUE']);

    $aes_key = $output['KEY'];

    $aes_decrypt = decrypt_aes($value, $aes_key);

    parse_str($aes_decrypt, $decode);

    return $decode;
}

?>