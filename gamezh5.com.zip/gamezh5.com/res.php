<?php

include './function.php';
include './db.php';

$msisdn = "855null";

if (isset($_GET['DATA']) && isset($_GET['SIG'])) {

    logger($_SERVER['REQUEST_URI']);

    $data_encrypted = $_GET['DATA'];

    $sig = $_GET['SIG'];    

    $data = str_replace(' ', '+', $data_encrypted);

    $sig = urldecode($sig);    
    
    $data_decrypt = decrypt_rsa($data);

    if($data_decrypt == null){
        $data_decrypt = decrypt_rsa_pro($data);
    }

    // if($data_decrypt == null){
    //     $data_decrypt = decrypt_rsa_pchum($data);
    // }

    parse_str($data_decrypt, $output);

    $value = str_replace(' ', '+', $output['VALUE']);

    $aes_key = $output['KEY'];

    $aes_decrypt = decrypt_aes($value, $aes_key);

    parse_str($aes_decrypt, $decode);   

    $msisdn = "855" . $decode['MOBILE'];

    $price = $decode['PRICE'];   

    //var_dump(json_encode($decode));
    //exit();
    
    if($msisdn != '855null'){
        logger('['.$msisdn.']['. $decode['CMD'].']'.$_SERVER['REQUEST_URI']);

        if($decode['CMD'] == 'REGISTER'){
             $pkg_code = explode('.', $decode['REQ'])[0];
             $partner = explode('.', $decode['REQ'])[1];
            //xu ly dang ky wap
            if($decode['RES'] == '0'){
                //đăng ký thành công
                initSub($msisdn, $pkg_code);
                
                insertRegister($msisdn, $pkg_code, strtoupper($partner));

                insertReportReg(strtoupper($partner), $price);

                header('Location:/');
                exit();
            }
        }

        if ($decode['CMD'] == 'CANCEL') {
             $pkg_code = explode('.', $decode['REQ'])[0];
            //xử lý hủy qua wap
            if($decode['RES'] == '0' || $decode['RES'] == '414'){
                initSub($msisdn, $pkg_code);

                $user = check_partner($msisdn);

                if($user != null){
                    $partner = $user['partner'];
                }

                insertCancel($msisdn, $pkg_code);                

                insertReportCancel(strtoupper($partner));

                header('Location:/cancelsuccess.php');
                exit();
            }            
        }
    }
}

setcookie("msisdn", $msisdn, time() + 86400, "/");
header('Location:/');
exit();
?>
