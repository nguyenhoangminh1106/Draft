<?php 

$is_reg = false;

if (isset($_COOKIE["is_reg"])) {
    $is_reg = $_COOKIE['is_reg'];
}

?>

<header>
    <nav class="ygame-nav">
        <div class="container">
            <div class="ygame-navbar">
                <div class="ygame-logo-header">
                    <a href="<?php echo $context_path ?>/"><img src="<?php echo $context_path ?>/new-images-1/header/logo-Game-H5.png" alt="" class="logo-ygame-pc"></a>
                    <a href="<?php echo $context_path ?>/"><img src="<?php echo $context_path ?>/new-images-1/header/LOGO-YGAME-MOBILE.png" alt="" class="logo-ygame-mobile"></a>
                </div>
                <div class="ygame-menu-header">
                    <ul class="ygame-menu-nav navbar-nav navbar-right nav-menu" >
                        <li class="text-center ygame-menu-item"> 
                            <a href="<?php echo $context_path ?>/"> 
                                <div class="menu-name">Home</div>
                            </a>
                        </li>
                        <li class="text-center ygame-menu-item">                           
                            <a href="<?php echo $context_path ?>/introduction"> 
                               <!-- <img src="<?php echo $context_path ?>/new-images-1/header/ico_game_hov_1.png"> -->
                                <div class="menu-name">About H5</div>
                            </a>
                        </li>

                        <li class="text-center ygame-menu-item">
                            <a href="<?php echo $context_path ?>/gamezh5"> 
                                <!-- <img src="<?php echo $context_path ?>/new-images-1/header/ico_game_hov_1.png"> -->
                                <div class="menu-name">Game</div>
                            </a>
                        </li> 

                        <!-- <li class="text-center ygame-menu-item">
                            <a href="#"> 
                                <img src="<?php echo $context_path ?>/new-images-1/header/HUONG-DAN.png">
                                <div class="menu-name">News</div>
                            </a>
                        </li>  -->

                        <li class="text-center ygame-menu-item">
                            <a href="<?php echo $context_path ?>/guide" class="navigate-ycoin-page">
<!--                                <img src="<?php echo $context_path ?>/new-images-1/header/YCOIN.png">-->
                                <div class="menu-name">Guide</div>
                            </a>
                        </li> 

                        <li class="text-center ygame-menu-item">
                            <a href="<?php echo $context_path ?>/promotion"> 
<!--                                <img src="<?php echo $context_path ?>/new-images-1/header/CODE.png">-->
                                <div class="menu-name">Promotion</div>
                            </a>
                        </li> 
                        <?php if(!$is_reg) { ?>
                            <li class="text-center ygame-menu-item">
                                <a data-toggle="modal" data-target="#login-modal"> 
                                    <div class="menu-name">Login</div>
                                </a>
                            </li> 
                        <?php } else { ?>
                            <li class="text-center ygame-menu-item">
                                <a href="<?php echo $context_path ?>/account">
    <!--                                <img src="<?php echo $context_path ?>/new-images-1/header/CHUA-DANG-NHAP.png" class="user-avatar">-->
                                    <div class="menu-name">Account</div>
                                </a>
                            </li>
                        <?php } ?>                    
                        <!-- <li class="text-center ygame-menu-item">
                            <a onclick="changeLang()"> <img src="https://ghdc.vn/Content/images/vnm.png"></a>
                        </li> -->
                    </ul>
                </div>
            </div>
        </div>
    </nav>
</header>

<style>
            .loginmodal-container {
               /* padding: 30px;*/
                max-width: 350px;
                width: 100% !important;
                background-color: #F7F7F7;
                margin: 0 auto;
                border-radius: 2px;
                box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
                overflow: hidden;
            }

            .loginmodal-container h1 {
                text-align: center;
                font-size: 1.8em;               
            }

            .loginmodal-container h5 {
                text-align: center;
                font-size: 13px;
            }

            .loginmodal-container input[type=submit] {
                width: 100%;
                display: block;
                margin-bottom: 10px;
                position: relative;
            }

            .loginmodal-container input[type=text], input[type=password], input[type=number] {
                height: 44px;
                font-size: 16px;
                width: 100%;
                margin-bottom: 10px;
                -webkit-appearance: none;
                background: #fff;
                border: 1px solid #d9d9d9;
                border-top: 1px solid #c0c0c0;
                /* border-radius: 2px; */
                padding: 0 8px;
                box-sizing: border-box;
                -moz-box-sizing: border-box;
            }

            .loginmodal-container input[type=text]:hover, input[type=password]:hover , input[type=number]:hover {
                border: 1px solid #b9b9b9;
                border-top: 1px solid #a0a0a0;
                -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
                -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
                box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
            }

            .loginmodal {
                text-align: center;
                font-size: 14px;
                font-weight: 700;
                height: 36px;
                padding: 0 8px;
                /* border-radius: 3px; */
                /* -webkit-user-select: none;
                  user-select: none; */
            }

            .loginmodal-submit {
                /* border: 1px solid #3079ed; */
                border: 0px;
                color: #fff;
                text-shadow: 0 1px rgba(0,0,0,0.1); 
                background-color: #4d90fe;
                padding: 17px 0px;
                font-size: 14px;
                /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
            }

            .loginmodal-submit:hover {
                /* border: 1px solid #2f5bb7; */
                border: 0px;
                text-shadow: 0 1px rgba(0,0,0,0.3);
                background-color: #357ae8;
                /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
            }

            .loginmodal-container a {
                text-decoration: none;
                color: #666;
                font-weight: 400;
                text-align: center;
                display: inline-block;
                opacity: 0.6;
                transition: opacity ease 0.5s;
            }

            .login-help{
                font-size: 13px;
                text-align: center;
            }
        </style>

<!-- Modal Login -->
<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content loginmodal-container">     
      <div class="modal-body">
        <h1>Login</h1>
        <form action="login.php" method="POST" style="text-align:center;">
            <input autocomplete="off" maxlength="11" onkeypress="return isNumberKey(event);" pattern="[0-9]*" type="number" name="user" placeholder="Phone number" autocomplete="off">
            <input type="password" name="pass" placeholder="Password">
            <input type="submit" name="login" class="login loginmodal-submit" value="Login">
            <span style="text-align: center; font-size: 14px;">To register send <b>GO 10c/day</b> or <b>PRO 15c/day</b> to <b>1541</b>.</br>To get the password send <b>PW</b> to <b>1541</b></span>
        </form>
      </div>      
    </div>
  </div>
</div>

<script type="text/javascript">
            //<![CDATA[
            function isNumberKey(evt) {
                evt = (evt) ? evt : window.event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                return true;
            }
            //]]>
</script>

<!-- <script>
function changeLang() {
    var url = window.location.href;    
    url = url.replace('html5.fzone.vn', 'html5.fzone.vn/vi');
    window.location.replace(url);
}
</script> -->
