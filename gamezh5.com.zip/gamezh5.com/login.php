<?php
include_once ('./db.php');
if (isset($_POST['user']) && isset($_POST['pass'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    $data = login($user, $pass);

    if (isset($data['msisdn'])) {
        setcookie("msisdn", $data['msisdn'], time() + 86400, "/");
        header('Location: /login-success');
        exit();
    } else {
        header('Location: /');
        exit();
    }
} else {
    header('Location: /');
    exit();
}
?>

