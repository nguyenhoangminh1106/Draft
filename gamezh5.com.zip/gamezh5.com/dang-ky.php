<?php
include './function.php';
include './config.php';
include './db.php';

if(isset($_GET['cpid'])){
	
	$cpid = $_GET['cpid'];

	$price = '100000';

    $pkg_code = 'GHD_GameH5_GoGame_Daily';

    $msisdn = '';
            
    $req_id = $pkg_code .'.'. $cpid .'.'. round(microtime(true));

    $input = "SUB=" . $pkg_code . "&MOBILE=" . $msisdn . "&CATE=CONTENT&ITEM=" . $pkg_code . "&SUB_CP=GHD&CONT=" . $pkg_code . "&PRICE=" . $price . "&REQ=" . $req_id . "&SOURCE=WAP";

    $param = "PRO=GHD&SER=GHD_GameH5&SUB=" . $pkg_code . "&CMD=REGISTER";

    $aes_key = bin2hex(openssl_random_pseudo_bytes(16));

    $value_encrypt_aes = encrypt_aes($input, $aes_key);

    $value_with_key = 'value=' . $value_encrypt_aes . '&key=' . $aes_key;

    $encode = encrypt_rsa($value_with_key);

    $sign = sign_data($encode, $pri_cp_path);

    $link = $mps_url . 'charge.html?' . $param . '&DATA=' . urlencode($encode) . '&SIG=' . $sign;

    header('Location: ' . $link);
    exit();
}
?>