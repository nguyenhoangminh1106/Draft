<?php
	include_once ('./config.php');
	include_once ('./db.php');
	include_once ('./function.php');
?>
<?php
if (isset($_COOKIE["msisdn"])) {
	$msisdn = $_COOKIE['msisdn'];
}
?>

<?php
if($msisdn != '855null'){    
    $data = check_register($msisdn);
    $regs_active = get_active($msisdn);
    if (isset($data['pkg_code'])) {
        $is_reg = true;
    }

    $regs = array();
    if ($regs_active != null) {
        foreach ($regs_active as $i => $dk) {
            array_push($regs, $dk['pkg_code']);
        }
    }
}
?>

<?php 
	include_once ('./header.php');
	include_once ('./menu.php');
	include_once ('./slide.php');
?>

<style>
	table {
	  font-family: arial, sans-serif;
	  border-collapse: collapse;
	  width: 100%;
	padding: 8px;
	}

	td, th {
	  border: 1px solid #dddddd;
	  text-align: left;
	  padding: 8px;
	}

	tr:nth-child(even) {
	  /*background-color: #dddddd;*/
	}

	.account{
		background-color: white;
		padding-top: 20px;
		padding-bottom: 20px;
	}
</style>


<div class="container account">
	<center><h3>Account information</h3></center>
	<table>	  
	  <tr>
	    <th>Phone</th>
	    <td><?php echo $msisdn ?></td>	   
	  </tr>

	  <tr>
	    <th>Package</th>
	    <td><?php 
	    	if(in_array('GHD_GameH5_GoGame_Daily', $regs, true)){
	    		echo "GoGame (10 cent) |";
	    	} 
	    	if(in_array('GHD_GameH5_GamePro_Daily', $regs, true)){
	    		echo " GamePro (15 cent)";
	    	} ?>	    	
	    </td>	   
	  </tr>

	  

	</table>
<center>
	
	<?php if(in_array('GHD_GameH5_GoGame_Daily', $regs, true)){ ?>
		<a href="/cancel.php?pkg=GHD_GameH5_GoGame_Daily" class="register-button">CANCEL GO</a>
	<?php } ?>
	
	<?php if(in_array('GHD_GameH5_GamePro_Daily', $regs, true)){ ?>
		<a href="/cancel.php?pkg=GHD_GameH5_GamePro_Daily" class="register-button">CANCEL PRO</a>
	<?php } ?>    
</center>
</div>

<?php 
include_once ('./footer.php');
?>
