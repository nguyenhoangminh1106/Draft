<?php
include './db.php';
include './header.php';
include './menu.php';

$listArticle = getSystemArticle('guide');
?>

<section class="menu-banner-top"></section>
<section style="background-color: rgba(204,204,204, 0.2);">
    <div class="game">
        <div style="padding-top: 20px; padding-bottom: 20px;" class="container resetp_ipad">
			<?php echo $listArticle['content'] ?>
        </div>
    </div>
</section>
<style>

    table, th, td {
      border: 1px solid black;

      .center {
          margin-left: auto !important;
          margin-right: auto !important;
      }
  }

  .step {
    max-width: 100%;
}

    ul {
      margin: 0;
  }
  ul.dashed {
      list-style-type: none;
  }
  ul.dashed > li {
      text-indent: -5px;
      text-align: justify;
  }
  ul.dashed > li:before {
      content: "- ";
      text-indent: -5px;
  }

</style>
<?php include './footer.php'; ?>