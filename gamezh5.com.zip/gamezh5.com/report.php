<?php
include_once './db.php';
date_default_timezone_set('UTC');
$datas = getReport();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Report</title>        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />        
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>
            .title{
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                text-align: center;
            }
            #customers {
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
                text-align: center;
                font-size: 13px;
            }

            #customers td, #customers th {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: center;
            }

            #customers tr:nth-child(even){background-color: #f2f2f2;}

            #customers tr:hover {background-color: #ddd;}

            #customers th {
                width: 10%;
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #0063af;
                color: white;
                text-align: center;
            }
        </style>
    </head>
    <body>        
        <h3 class="title">BÁO CÁO H5 GAME METFONE NGÀY <?php echo date("d/m/Y") ?></h3>
        <table id="customers">
            <tr>
                <th>Ngày</th>
                <th>Active</th>
                <th>Phát triển</th>
                <th>Đăng ký</th>
                <th>Hủy</th>
                <th>GH Thành công</th>                
                <th>DT Đăng ký</th>
                <th>DT Gia hạn</th>
                <th>DT Tổng</th>
            </tr>
            <?php
            foreach ($datas as $i => $data) {
                ?>
                <tr>
                    <td><?php echo $data['report_date'] ?></td>
                    <td><?php echo $data['total_subs'] ?></td>
                    <td><?php echo $data['daily_subs'] ?></td>
                    <td><?php echo $data['register'] ?></td>
                    <td><?php echo $data['cancel'] ?></td>
                    <td><?php echo $data['renew_suc'] ?></td>                    
                    <td><?php echo '$'.($data['reg_income']/1000000) ?></td>
                    <td><?php echo '$'.($data['renew_income']/1000000) ?></td>
                    <td><?php echo '$'.($data['total_income']/1000000) ?></td>
                </tr>                             
            <?php } ?>
        </table>
    </body>
</html>