<?php
include './db.php';
include './header.php';
include './menu.php';
include './slide.php';
?>

<?php
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    $game = getGameById($id);
    if(!$game){
    	header('Location: http://html5.fzone.vn/');
	exit;}
} else {
    header('Location:/404.php');
    exit;
}
?>
<link rel="stylesheet" href="<?php echo $context_path ?>/css/detail.css">
<section style="margin-bottom: 30px" id="second">
    <div class="container info-game-content t_bdrus" style="box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);background-color:white">
        <div class="container info-game" id="info-game">
            <div class="row">
                <div class="col-sm-10">
                    <div class="row">
                        <div class="col-sm-2 col-5 size_icon">
                            <img src="<?php echo $context_path ?>/images/game/<?php echo $game['image'] ?>" width="100%" alt="">
                        </div>
                        <div class="col-sm-10 col-7 pd_col pdicon_mb">

                            <div class="row title-game">
                                <h5 style="font-weight: bold;"><?php echo $game['name_eng'] ?></h5>
                            </div>
                            <div class="row">
                                <ul style="margin-bottom: 0px;">
                                    <li><span>Category : <?php echo $game['category_eng'] ?></span></li>
                                    <li><span>Player : <?php echo $game['viewed'] ?></span></li>
                                    <li><span>Age : <?php echo $game['age'] ?>+</span></li>
                                    <!--<li><span><?php echo $game['intro_eng'] ?></span></li>-->
                                    <li><span>Language : </span><img class="game-lang" src="<?php echo $context_path ?>/img/eng.png" /></li>
                                    <li><span>Graphics : 2D</span></li>
   
                                </ul>
                                <div class="giftcode-playnow mb-view">
                                <ul class="gift-play row" style="margin-right: 0">                                    
                                    <li class="col-sm-6 col-6" id="playnow_mb">
                                        <a id="btn_play_9" style="text-decoration: none;" href='<?php echo $context_path ?>/play?id=<?php echo $game['id'] ?>'>
                                            <img style="width: 120%;" class="w_mb" src="<?php echo $context_path ?>/img/new/btn_play_nor.png" width="100%">
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            </div>                           
                                                            
                        </div>
                    </div>
                </div>

                <div class="col-sm-2 pc-view dp_ipab">
                    <div class="row pddt_ipab" width="80%">
                        <a href='<?php echo $context_path ?>/play?id=<?php echo $game['id'] ?>'>
                            <img class="w_ipab" id="icon_playnow" src="<?php echo $context_path ?>/img/new/btn_play_nor.png" width="100%">
                        </a>
                    </div> 
                </div>

            </div>
        </div>
    </div>
</section>
<section id="third" style="margin-bottom: 30px">
    <div class="container t_bdrus" style="box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);padding-top:0px;padding-left:0px;padding-right: 0px;background-color:white">
        <div class="container" style="padding:0 0 20px 0" id="newevent">
            <ul class="nav nav-pills nav-justified pdb5_mb" role="pill">
                <li class="nav-item">
                    <a class="nav-link nav-active bold active show" style="border-top-left-radius:5px;" data-toggle="tab" href="#detail" id="detail_pill">DETAIL</a>
                </li>
            </ul>
        </div>
        <div class="container" style="padding: 10px">
            <div class="tab-content">                        
                <div id="detail" class="container fade-in tab-pane active show">
                    <article>
                        <p style="text-align: justify"><?php echo $game['intro_eng'] ?></p>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include './footer.php'; ?>
