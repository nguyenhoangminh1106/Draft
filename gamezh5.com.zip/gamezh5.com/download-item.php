<?php 

include './function.php';
include './config.php';
include './mps-otp-process.php';

                $pkg_code = 'GHD_GameH5_GamePro_Daily';

                $price = '20000';

                $msisdn = '974579594';

                $req_id = round(microtime(true));

	            $input = "SUB=" . $pkg_code . "&MOBILE=" . $msisdn . "&CATE=B2&ITEM=GHD_GameH5_GamePro_Daily&SUB_CP=GHD&CONT=" . $pkg_code . "&PRICE=" . $price . "&REQ=" . $req_id . "&SOURCE=CLIENT";

                $param = "PRO=GHD&SER=GHD_GameH5&SUB=" . $pkg_code . "&CMD=B2";

                $aes_key = bin2hex(openssl_random_pseudo_bytes(16));

                $value_encrypt_aes = encrypt_aes($input, $aes_key);

                $value_with_key = 'value=' . $value_encrypt_aes . '&key=' . $aes_key;

                $encode = encrypt_rsa_pro($value_with_key);

                $sign = sign_data_pro($encode, $pri_cp_path_pro);

                $link = $mps_url . 'charge.html?' . $param . '&DATA=' . urlencode($encode) . '&SIG=' . $sign;

                // var_dump($input);
                // var_dump($param);

                // var_dump($link);

                // exit();

                $res_mps = file_get_contents($link);

                parse_str($res_mps, $output);

                var_dump($input);
                var_dump($param);

                var_dump($res_mps);

                $decode = otp_res_process($output['DATA'], $output['SIG']);

                

                var_dump(json_encode($decode));
                exit();

?>